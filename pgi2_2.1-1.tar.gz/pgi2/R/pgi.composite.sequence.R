pgi.composite.sequence <-
function(...,inf.params,con.params) {



}

